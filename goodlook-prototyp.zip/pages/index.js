import Head from 'next/head'
import { useState } from 'react'

export default function Home() {
  const [step, setStep] = useState('start')
  const [occasion, setOccasion] = useState('')

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <Head>
        <title>GoodLook</title>
      </Head>
      <h1>GoodLook</h1>
      {step === 'start' && (
        <>
          <p>Scanne ein Kleidungsstück, um ein Outfit zu erstellen.</p>
          <button onClick={() => setStep('scan')}>Kleidung scannen</button>
        </>
      )}
      {step === 'scan' && (
        <>
          <p>[Scanner Platzhalter]</p>
          <button onClick={() => setStep('occasion')}>Outfit erstellen</button>
        </>
      )}
      {step === 'occasion' && (
        <>
          <p>Für welchen Anlass?</p>
          {['Alltag', 'Business', 'Date', 'Party'].map((label) => (
            <button key={label} onClick={() => setOccasion(label)} style={{ margin: '0.5rem' }}>
              {label}
            </button>
          ))}
          {occasion && <button onClick={() => setStep('generated')}>Outfit anzeigen</button>}
        </>
      )}
      {step === 'generated' && (
        <>
          <h2>Vorgeschlagenes Outfit ({occasion})</h2>
          <ul>
            <li>👕 Oberteil: Weißes Hemd</li>
            <li>👖 Hose: Dunkelblaue Jeans</li>
            <li>👟 Schuhe: Weiße Sneaker</li>
            <li>🕶️ Accessoire: Schwarze Sonnenbrille</li>
          </ul>
        </>
      )}
    </div>
  )
}
